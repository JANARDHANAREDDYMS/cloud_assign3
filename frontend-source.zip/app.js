// API Gateway configuration - replace with your values after deployment
const API_ENDPOINT = 'YOUR_API_ENDPOINT'; // e.g., 'https://abc123def.execute-api.us-east-1.amazonaws.com/prod'
const API_KEY = 'YOUR_API_KEY';

// Initialize the API client (assuming you've generated and included the SDK)
let apigClient;

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the API client with your API key
    apigClient = apigClientFactory.newClient({
        apiKey: API_KEY
    });
    
    // Set up event listeners
    document.getElementById('search-button').addEventListener('click', performSearch);
    document.getElementById('search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    document.getElementById('upload-form').addEventListener('submit', uploadPhoto);
});

function performSearch() {
    const searchQuery = document.getElementById('search-input').value.trim();
    if (!searchQuery) {
        alert('Please enter a search query');
        return;
    }
    
    // Show loading state
    const resultsContainer = document.getElementById('results-container');
    resultsContainer.innerHTML = '<p>Searching...</p>';
    
    // Call the search API
    const params = {
        q: searchQuery
    };
    
    apigClient.searchGet(params, {}, {})
        .then(function(response) {
            displayResults(response.data.results);
        })
        .catch(function(error) {
            console.error('Error performing search:', error);
            resultsContainer.innerHTML = '<p>Error performing search. Please try again.</p>';
        });
}

function displayResults(results) {
    const resultsContainer = document.getElementById('results-container');
    
    if (!results || results.length === 0) {
        resultsContainer.innerHTML = '<p>No photos found matching your search.</p>';
        return;
    }
    
    // Clear previous results
    resultsContainer.innerHTML = '';
    
    // Display each photo
    results.forEach(function(photo) {
        const photoCard = document.createElement('div');
        photoCard.className = 'photo-card';
        
        // Create image element
        const img = document.createElement('img');
        img.src = photo.url;
        img.alt = 'Photo result';
        
        // Create photo info section
        const infoDiv = document.createElement('div');
        infoDiv.className = 'photo-info';
        
        // Display labels
        const labelsDiv = document.createElement('div');
        labelsDiv.className = 'photo-labels';
        labelsDiv.textContent = 'Labels: ' + photo.labels.join(', ');
        
        // Assemble the card
        infoDiv.appendChild(labelsDiv);
        photoCard.appendChild(img);
        photoCard.appendChild(infoDiv);
        
        // Add to results container
        resultsContainer.appendChild(photoCard);
    });
}

function uploadPhoto(event) {
    event.preventDefault();
    
    const fileInput = document.getElementById('file-upload');
    const customLabelsInput = document.getElementById('custom-labels');
    
    if (!fileInput.files || fileInput.files.length === 0) {
        alert('Please select a file to upload');
        return;
    }
    
    const file = fileInput.files[0];
    const fileName = file.name;
    const customLabels = customLabelsInput.value.trim();
    
    // Read file as binary
    const reader = new FileReader();
    reader.onload = function(e) {
        const binaryData = e.target.result;
        
        // Prepare headers
        const headers = {
            'Content-Type': file.type
        };
        
        // Add custom labels if provided
        if (customLabels) {
            headers['x-amz-meta-customLabels'] = customLabels;
        }
        
        // Call the upload API
        const params = {
            object: fileName
        };
        
        apigClient.photosObjectPut(params, binaryData, headers)
            .then(function(response) {
                alert('Photo uploaded successfully!');
                // Reset the form
                document.getElementById('upload-form').reset();
            })
            .catch(function(error) {
                console.error('Error uploading photo:', error);
                alert('Error uploading photo. Please try again.');
            });
    };
    
    reader.readAsArrayBuffer(file);
}