// Lambda function for searching photos
const AWS = require('aws-sdk');
const { Client } = require('@opensearch-project/opensearch');
const { defaultProvider } = require('@aws-sdk/credential-provider-node');
const createAwsOpensearchConnector = require('aws-opensearch-connector');

// Initialize AWS services
const lexRuntime = new AWS.LexRuntimeV2();

let opensearchClient;

// Main Lambda handler
exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    try {
        // Get query parameters
        const query = event.queryStringParameters && event.queryStringParameters.q;
        
        if (!query) {
            return {
                statusCode: 400,
                headers: {
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({ 
                    message: 'Query parameter q is required' 
                })
            };
        }
        
        console.log(`Search query: ${query}`);
        
        // Step 1: Use Lex to extract keywords from the query
        const keywords = await extractKeywords(query);
        console.log('Extracted keywords:', keywords);
        
        if (keywords.length === 0) {
            return {
                statusCode: 200,
                headers: {
                    'Access-Control-Allow-Origin': '*'
                },
                body: JSON.stringify({ results: [] })
            };
        }
        
        // Step 2: Search OpenSearch with these keywords
        const searchResults = await searchOpenSearch(keywords);
        
        console.log('Search results:', searchResults);
        
        // Step 3: Format and return the results
        const formattedResults = searchResults.map(result => ({
            url: `https://${result.bucket}.s3.amazonaws.com/${result.objectKey}`,
            labels: result.labels
        }));
        
        return {
            statusCode: 200,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                results: formattedResults
            })
        };
    } catch (error) {
        console.error('Error processing search:', error);
        
        return {
            statusCode: 500,
            headers: {
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify({
                message: 'Error processing search request',
                error: error.message
            })
        };
    }
};

const getOpenSearchClient = async () => {
    if (opensearchClient) return opensearchClient;
    
    const awsCredentials = await defaultProvider()();
    const connector = createAwsOpensearchConnector({
      credentials: awsCredentials,
      region: process.env.AWS_REGION,
    });
    
    opensearchClient = new Client({
      node: `https://${process.env.OPENSEARCH_DOMAIN}`,
      Connection: connector,
    });
    
    return opensearchClient;
};

async function searchOpenSearch(keywords) {
    try {
      const client = await getOpenSearchClient();
      
      // Create a query that searches for any of the keywords in the labels field
      const query = {
        query: {
          bool: {
            should: keywords.map(keyword => ({
              match: {
                labels: keyword
              }
            })),
            minimum_should_match: 1
          }
        }
      };
      
      const response = await client.search({
        index: 'photos',
        body: query
      });
      
      console.log(`Search results: ${JSON.stringify(response.body.hits.hits)}`);
      
      // Format the results
      return response.body.hits.hits.map(hit => ({
        objectKey: hit._source.objectKey,
        bucket: hit._source.bucket,
        createdTimestamp: hit._source.createdTimestamp,
        labels: hit._source.labels,
        score: hit._score
      }));
    } catch (error) {
      console.error('Error searching OpenSearch:', error);
      throw error;
    }
}

// Function to extract keywords using Lex
async function extractKeywords(query) {
    const botId = process.env.LEX_BOT_ID;
    const botAliasId = 'TSTALIASID'; // You'll need to update this with the actual alias ID
    
    try {
        const params = {
            botId: botId,
            botAliasId: botAliasId,
            localeId: 'en_US',
            sessionId: `search-session-${Date.now()}`,
            text: query
        };
        
        const lexResponse = await lexRuntime.recognizeText(params).promise();
        console.log('Lex response:', JSON.stringify(lexResponse, null, 2));
        
        // Extract keywords from slots
        const keywords = [];
        
        if (lexResponse.sessionState && 
            lexResponse.sessionState.intent && 
            lexResponse.sessionState.intent.slots) {
            
            const slots = lexResponse.sessionState.intent.slots;
            
            // Extract the primary keyword
            if (slots.keyword && slots.keyword.value && slots.keyword.value.interpretedValue) {
                keywords.push(slots.keyword.value.interpretedValue.toLowerCase());
            }
            
            // Extract the second keyword if present
            if (slots.keywordTwo && slots.keywordTwo.value && slots.keywordTwo.value.interpretedValue) {
                keywords.push(slots.keywordTwo.value.interpretedValue.toLowerCase());
            }
        }
        
        return keywords;
    } catch (error) {
        console.error('Error calling Lex:', error);
        throw error;
    }
}