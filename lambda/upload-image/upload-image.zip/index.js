const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
  const bucket = process.env.PHOTOS_BUCKET;
  const filename = event.pathParameters.filename;
  const contentType = event.headers['Content-Type'] || 'application/octet-stream';
  const customLabels = event.headers['x-amz-meta-customlabels'] || '';
  const body = Buffer.from(event.body, 'base64'); // Decode binary image

  const params = {
    Bucket: bucket,
    Key: filename,
    Body: body,
    ContentType: contentType,
    Metadata: {
      customlabels: customLabels
    }
  };

  await s3.putObject(params).promise();

  return {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin': '*'
    },
    body: JSON.stringify({ message: 'Upload successful' })
  };
};