// Lambda function for indexing photos
const AWS = require('aws-sdk');

// Initialize AWS services
const rekognition = new AWS.Rekognition();
const s3 = new AWS.S3();
// We'll initialize OpenSearch client when we implement that part

// Main Lambda handler
exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    try {
        // Process each record (S3 PUT event)
        for (const record of event.Records) {
            // Extract bucket and object key information
            const bucket = record.s3.bucket.name;
            const objectKey = decodeURIComponent(record.s3.object.key.replace(/\+/g, ' '));
            
            console.log(`Processing image: ${bucket}/${objectKey}`);
            
            // Step 1: Get image labels from Rekognition
            const rekognitionLabels = await detectLabels(bucket, objectKey);
            console.log('Rekognition labels:', rekognitionLabels);
            
            // Step 2: Get custom labels from S3 metadata
            const customLabels = await getCustomLabels(bucket, objectKey);
            console.log('Custom labels:', customLabels);
            
            // Step 3: Combine all labels
            const allLabels = [...rekognitionLabels, ...customLabels];
            
            // Step 4: Create JSON document for indexing
            const timestamp = record.eventTime || new Date().toISOString();
            const document = {
                objectKey: objectKey,
                bucket: bucket,
                createdTimestamp: timestamp,
                labels: allLabels
            };
            
            console.log('Document to index:', document);
            
            // Step 5: Index in OpenSearch (we'll implement this later)
            // await indexDocument('photos', document);
            
            console.log(`Successfully processed ${objectKey}`);
        }
        
        return {
            statusCode: 200,
            body: JSON.stringify('Photo indexed successfully')
        };
    } catch (error) {
        console.error('Error processing image:', error);
        throw error;
    }
};

// Function to detect labels using Rekognition
async function detectLabels(bucket, objectKey) {
    const params = {
        Image: {
            S3Object: {
                Bucket: bucket,
                Name: objectKey
            }
        },
        MaxLabels: 50,
        MinConfidence: 70
    };
    
    try {
        const rekognitionResponse = await rekognition.detectLabels(params).promise();
        
        // Extract just the label names from the response
        return rekognitionResponse.Labels.map(label => label.Name.toLowerCase());
    } catch (error) {
        console.error('Error calling Rekognition:', error);
        throw error;
    }
}

// Function to get custom labels from S3 metadata
async function getCustomLabels(bucket, objectKey) {
    const params = {
        Bucket: bucket,
        Key: objectKey
    };
    
    try {
        const headResponse = await s3.headObject(params).promise();
        
        // Check if there are custom labels in the metadata
        // Note: AWS converts header names to lowercase in the metadata object
        if (headResponse.Metadata && headResponse.Metadata['customlabels']) {
            // Parse the comma-separated labels, trim whitespace, and convert to lowercase
            return headResponse.Metadata['customlabels']
                .split(',')
                .map(label => label.trim().toLowerCase())
                .filter(label => label.length > 0);
        }
        
        return [];
    } catch (error) {
        console.error('Error getting S3 object metadata:', error);
        throw error;
    }
}

// We'll implement the indexDocument function later when we add OpenSearch